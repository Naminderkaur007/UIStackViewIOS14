
//Apple introduced the stack view back in iOS 9 and made a bold claim for it during a session on Auto Layout at WWDC 2015:

//Custom Spacing (iOS 11

//Starting with iOS 14, you can set the backgroundColor of stackView

//Distribution :- fill, fill Equalily, fill Propotionally, Equal spacing, Equal Centering

//Alignement :-  fill, top, center, bottom, first Baseline, last Baseline


import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var stackView: UIStackView!
    var labelView: UILabel!
    var backgroundView = UIView()
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        labelView = UILabel(frame: CGRect(x: 0, y: 0, width: 50, height: 100))
        labelView.translatesAutoresizingMaskIntoConstraints = false
        labelView.text = "IceCream"
        labelView.backgroundColor = .systemPink
        labelView.layer.cornerRadius = 10.0
        
        backgroundView.translatesAutoresizingMaskIntoConstraints = false
        backgroundView.backgroundColor = .purple
        backgroundView.layer.cornerRadius = 10.0
        
        //*****************
     //   addInList()
       // customSpacing()
       // removeFromList()
       // remove()
        addViewInBackground()
        addConstraints()
    }
    
    func addInList(){
       //arrangedSubview Array
        
      //  stackView.addArrangedSubview(labelView)
        stackView.insertArrangedSubview(labelView, at: 1)
    }
    
    func customSpacing(){
        //custom spacing
        stackView.setCustomSpacing(15.0, after: labelView)
    }
    func removeFromList(){
        //point
        stackView.removeArrangedSubview(labelView)
    }
    
    func remove(){
        //point
        labelView.removeFromSuperview()
    }
    
    //*****************
    func addViewInBackground() {
        
        //SubView Array
        
        stackView.insertSubview(backgroundView, at: 0)
        //stackView.addSubview(backgroundView)
    }
    func addConstraints(){
        
        NSLayoutConstraint.activate([
            stackView.leadingAnchor.constraint(equalTo: backgroundView.leadingAnchor),
            stackView.trailingAnchor.constraint(equalTo: backgroundView.trailingAnchor),
            stackView.topAnchor.constraint(equalTo: backgroundView.topAnchor),
            stackView.bottomAnchor.constraint(equalTo: backgroundView.bottomAnchor)
            ])
    }

}

